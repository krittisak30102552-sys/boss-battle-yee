import { useEffect, useRef, useState } from "react";
import { Game, HudState, WEAPON_INFO } from "./game/Game";
import { downloadSingleHtml, downloadSourceZip } from "./utils/download";

const INITIAL: HudState = {
  status: "menu",
  playerHp: 250,
  playerMax: 250,
  bossHp: 3000,
  bossMax: 3000,
  boost: 100,
  weapon: 0,
  morphing: false,
  charge: 0,
  healCd: 0,
  dashCd: 0,
  phase: 1,
  hurt: 0,
  hits: 0,
  action: "",
  locked: false,
  time: 0,
  blocking: false,
  absorbing: false,
  ult: 0,
  refocus: 0,
  heat: 0,
  overheat: false,
  sentries: 0,
  snaps: 0,
  hint: "",
};

const fmt = (t: number) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;

function Bar({ value, max, color, h = "h-3" }: { value: number; max: number; color: string; h?: string }) {
  return (
    <div className={`w-full ${h} bg-black/60 border border-white/20 skew-x-[-12deg] overflow-hidden`}>
      <div className="h-full transition-[width] duration-100" style={{ width: `${Math.max(0, (value / max) * 100)}%`, background: color }} />
    </div>
  );
}

function DownloadButtons({ compact = false }: { compact?: boolean }) {
  const [busy, setBusy] = useState(false);
  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    try {
      await fn();
    } finally {
      setBusy(false);
    }
  };
  const base =
    "pointer-events-auto cursor-pointer border font-bold tracking-wide transition hover:brightness-125 disabled:opacity-50 " +
    (compact ? "px-3 py-1.5 text-xs" : "px-5 py-3 text-sm");
  return (
    <div className={`flex ${compact ? "gap-2" : "gap-3 flex-wrap justify-center"}`}>
      <button disabled={busy} onClick={() => run(downloadSourceZip)} className={`${base} border-cyan-300/60 bg-cyan-500/15 text-cyan-100`}>
        ⬇ โค้ดเกม (.zip)
      </button>
      <button disabled={busy} onClick={() => run(downloadSingleHtml)} className={`${base} border-amber-300/60 bg-amber-500/15 text-amber-100`}>
        ⬇ เกมไฟล์เดียว (.html)
      </button>
    </div>
  );
}

const KEYS: Array<[string, string]> = [
  ["W A S D", "เดิน"],
  ["เมาส์", "หมุนกล้อง / เล็ง"],
  ["คลิกซ้าย", "ใช้อาวุธ / สกิลที่เลือก"],
  ["SPACE", "กระโดด / กดค้างเพื่อบิน"],
  ["SHIFT", "Dash หลบ (ถือค้อน = Battering Ram)"],
  ["1-9 · 0 · G", "เลือกสกิลนาโน (G = เกาน์ทเล็ตไม้ตาย)"],
  ["Q / E / ล้อเมาส์", "สลับสกิลก่อนหน้า / ถัดไป"],
  ["T", "ซ่อมเกราะด้วยนาโนบอท (+80, คูลดาวน์ 30 วิ)"],
  ["R", "ถอดชุด / ใส่ชุด Mark 85"],
  ["P / ESC", "พัก"],
  ["ลูกศร / ลากเมาส์ขวา", "หมุนกล้อง (ถ้าล็อกเมาส์ไม่ได้)"],
];

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [hud, setHud] = useState<HudState>(INITIAL);
  const [error, setError] = useState("");
  const [chooseMode, setChooseMode] = useState(false);
  const [deviceMode, setDeviceMode] = useState<"desktop" | "mobile" | null>(null);
  const [tonyMode, setTonyMode] = useState(false);

  useEffect(() => {
    if (!mountRef.current) return;
    let game: Game;
    try {
      game = new Game(mountRef.current, setHud);
    } catch (e) {
      setError(String(e));
      return;
    }
    gameRef.current = game;
    if (typeof location !== "undefined" && location.search.includes("debug")) (window as unknown as { __game: Game }).__game = game;
    return () => {
      game.dispose();
      gameRef.current = null;
    };
  }, []);


const holdKey = (code: string, label: string, extra = "") => (
  <button key={code} type="button"
    onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); document.dispatchEvent(new KeyboardEvent("keydown", { code, key: code.startsWith("Key") ? code.slice(3).toLowerCase() : code === "Space" ? " " : code.startsWith("Arrow") ? code.slice(5).toLowerCase() : code === "ShiftLeft" ? "Shift" : code, bubbles: true })); }}
    onPointerUp={() => document.dispatchEvent(new KeyboardEvent("keyup", { code, key: code.startsWith("Key") ? code.slice(3).toLowerCase() : code === "Space" ? " " : code.startsWith("Arrow") ? code.slice(5).toLowerCase() : code === "ShiftLeft" ? "Shift" : code, bubbles: true }))}
    onPointerCancel={() => document.dispatchEvent(new KeyboardEvent("keyup", { code, key: code.startsWith("Key") ? code.slice(3).toLowerCase() : code === "Space" ? " " : code.startsWith("Arrow") ? code.slice(5).toLowerCase() : code === "ShiftLeft" ? "Shift" : code, bubbles: true }))}
    onLostPointerCapture={() => document.dispatchEvent(new KeyboardEvent("keyup", { code, key: code.startsWith("Key") ? code.slice(3).toLowerCase() : code === "Space" ? " " : code.startsWith("Arrow") ? code.slice(5).toLowerCase() : code === "ShiftLeft" ? "Shift" : code, bubbles: true }))}
    onContextMenu={(e) => e.preventDefault()}
    className={`h-12 w-12 rounded-xl border border-white/35 bg-black/65 text-lg font-black text-white shadow-lg active:bg-cyan-500/50 active:scale-95 ${extra}`}>
    {label}
  </button>
);

  
const cameraTouchRef = useRef<{ x: number; y: number } | null>(null);
const stickPointerRef = useRef<number | null>(null);
const virtualKeysRef = useRef<Set<string>>(new Set());
const setVirtualKey = (code: string, down: boolean) => {
  const held = virtualKeysRef.current.has(code);
  if (down && !held) {
    virtualKeysRef.current.add(code);
    document.dispatchEvent(new KeyboardEvent("keydown", { code, key: code.startsWith("Key") ? code.slice(3).toLowerCase() : code === "Space" ? " " : code.startsWith("Arrow") ? code.slice(5).toLowerCase() : code === "ShiftLeft" ? "Shift" : code, bubbles: true }));
  } else if (!down && held) {
    virtualKeysRef.current.delete(code);
    document.dispatchEvent(new KeyboardEvent("keyup", { code, key: code.startsWith("Key") ? code.slice(3).toLowerCase() : code === "Space" ? " " : code.startsWith("Arrow") ? code.slice(5).toLowerCase() : code === "ShiftLeft" ? "Shift" : code, bubbles: true }));
  }
};
const moveStick = (e: React.PointerEvent<HTMLDivElement>) => {
  const rect = e.currentTarget.getBoundingClientRect();
  const dx = e.clientX - (rect.left + rect.width / 2);
  const dy = e.clientY - (rect.top + rect.height / 2);
  const max = rect.width * 0.34;
  const distance = Math.hypot(dx, dy) || 1;
  const scale = Math.min(1, max / distance);
  const x = dx * scale, y = dy * scale;
  const knob = e.currentTarget.querySelector<HTMLElement>("[data-stick-knob]");
  if (knob) knob.style.transform = "translate(" + x + "px," + y + "px)";
  const dead = rect.width * 0.13;
  setVirtualKey("KeyA", x < -dead);
  setVirtualKey("KeyD", x > dead);
  setVirtualKey("KeyW", y < -dead);
  setVirtualKey("KeyS", y > dead);
};
const releaseStick = () => {
  ["KeyW", "KeyA", "KeyS", "KeyD"].forEach((code) => setVirtualKey(code, false));
  const knob = document.querySelector<HTMLElement>("[data-stick-knob]");
  if (knob) knob.style.transform = "translate(0px,0px)";
};

    const bossPct = hud.bossHp / hud.bossMax;
  const showHud = hud.status === "playing" || hud.status === "paused";

  return (
    <div className="fixed inset-0 overflow-hidden bg-black text-white select-none" style={{ fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
      <div ref={mountRef} className="absolute inset-0" />

      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black text-red-300 p-8 text-center">
          ไม่สามารถเริ่ม WebGL ได้: {error}
        </div>
      )}

      {hud.snaps > 0 && (
        <div
          key={hud.snaps}
          className="snap-flash pointer-events-none absolute inset-0 z-[60] bg-white"
          style={{ background: "radial-gradient(circle at 50% 45%, #fff 0%, #fff6d6 40%, #ffd36b 100%)" }}
        />
      )}

      {/* ---------------- in-game HUD ---------------- */}
      {showHud && (
        <div className="pointer-events-none absolute inset-0">
          {/* damage vignette */}
          {hud.hurt > 0 && (
            <div
              key={hud.hurt}
              className="hurt-flash absolute inset-0"
              style={{ boxShadow: "inset 0 0 160px 40px rgba(255,0,0,0.65)" }}
            />
          )}

          {/* boss bar */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-[min(720px,88vw)]">
            <div className="flex items-end justify-between mb-1 px-1">
              <div className="text-lg font-black tracking-[0.25em] text-purple-200 drop-shadow">THANOS</div>
              <div className="text-xs text-purple-200/80">
                {hud.phase === 2 ? "PHASE II · RAGE" : "PHASE I"} · {hud.bossHp}/{hud.bossMax}
              </div>
            </div>
            <div className="relative">
              <Bar value={hud.bossHp} max={hud.bossMax} color="linear-gradient(90deg,#7c3aed,#c026d3)" h="h-4" />
              <div className="absolute top-0 bottom-0 left-1/2 w-px bg-white/60" />
            </div>
            <div className="h-7 mt-2 text-center text-sm font-bold text-amber-300 drop-shadow animate-pulse">{hud.action}</div>
          </div>

          {/* crosshair */}
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <div className={`w-8 h-8 rounded-full border-2 ${hud.blocking ? "border-cyan-300" : "border-cyan-200/70"} flex items-center justify-center`}>
              <div className="w-1 h-1 rounded-full bg-cyan-200" />
            </div>
            {hud.hits > 0 && (
              <div key={hud.hits} className="hit-marker absolute inset-0 flex items-center justify-center text-red-400 font-black text-2xl">
                ✕
              </div>
            )}
          </div>

          {hud.hint && (
            <div className="absolute left-1/2 top-[22%] -translate-x-1/2 border border-cyan-300/50 bg-black/60 px-4 py-2 text-center text-sm font-black text-cyan-100 shadow-lg">
              {hud.hint}
            </div>
          )}
          {hud.sentries > 0 && (
            <div className="absolute left-1/2 top-[30%] -translate-x-1/2 text-[11px] font-bold text-cyan-200/80">SENTRY ×{hud.sentries}</div>
          )}

          {/* player status */}
          <div className="absolute left-4 bottom-4 w-[min(260px,40vw)] space-y-1.5">
            <div>
              <div className="flex justify-between text-xs font-bold text-red-200 mb-1">
                <span>MARK 85 · NANOTECH</span>
                <span>
                  {hud.playerHp}/{hud.playerMax}
                </span>
              </div>
              <Bar value={hud.playerHp} max={hud.playerMax} color="linear-gradient(90deg,#dc2626,#f59e0b)" h="h-4" />
            </div>
            <div>
              <div className="text-[10px] font-bold text-cyan-200 mb-1">THRUSTERS</div>
              <Bar value={hud.boost} max={100} color="linear-gradient(90deg,#06b6d4,#a5f3fc)" h="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-[10px] font-bold text-amber-200 mb-1">
                <span>{hud.ult >= 100 ? "ULT พร้อม! — เลือก [G] เกาน์ทเล็ต" : "INFINITY ULT"}</span>
                <span>{Math.floor(hud.ult)}%</span>
              </div>
              <div className={hud.ult >= 100 ? "ult-ready" : ""}>
                <Bar value={hud.ult} max={100} color="linear-gradient(90deg,#f59e0b,#fde047,#ffffff)" h="h-2" />
              </div>
            </div>
            {(hud.refocus > 0 || hud.absorbing || hud.weapon === 1) && (
              <div>
                <div className="flex justify-between text-[10px] font-bold text-sky-200 mb-1">
                  <span>LIGHTNING REFOCUS · พลังงานที่ดูดไว้</span>
                  <span>{Math.round(hud.refocus * 100)}%</span>
                </div>
                <Bar value={hud.refocus} max={1} color="linear-gradient(90deg,#38bdf8,#e0f2fe)" h="h-2" />
              </div>
            )}
            {(hud.heat > 0.02 || hud.weapon === 2) && (
              <div>
                <div className={`flex justify-between text-[10px] font-bold mb-1 ${hud.overheat ? "text-red-300 animate-pulse" : "text-cyan-200"}`}>
                  <span>{hud.overheat ? "UNI-BEAM OVERHEAT" : "UNI-BEAM HEAT"}</span>
                  <span>{Math.round(hud.heat * 100)}%</span>
                </div>
                <Bar value={hud.heat} max={1} color={hud.overheat ? "linear-gradient(90deg,#ef4444,#f97316)" : "linear-gradient(90deg,#22d3ee,#fde047)"} h="h-2" />
              </div>
            )}
            <div className="flex gap-2 text-[11px] font-bold">
              <div className={`px-2 py-1 border ${hud.healCd > 0 ? "border-white/20 text-white/40" : "border-emerald-300/70 text-emerald-200"} bg-black/50`}>
                [T] ซ่อม {hud.healCd > 0 ? `${Math.ceil(hud.healCd)}s` : "พร้อม"}
              </div>
              <div className={`px-2 py-1 border ${hud.dashCd > 0 ? "border-white/20 text-white/40" : "border-cyan-300/70 text-cyan-200"} bg-black/50`}>
                [SHIFT] Dash {hud.dashCd > 0 ? `${hud.dashCd.toFixed(1)}s` : "พร้อม"}
              </div>
            </div>
          </div>

          {/* weapons */}
          <div className={`absolute bottom-3 left-1/2 w-[min(1040px,52vw)] -translate-x-1/2 ${deviceMode === "mobile" ? "hidden" : ""}`}>
            <div className="mb-2 text-center text-[11px] font-bold text-amber-200 drop-shadow">
              <span className="text-cyan-200">{WEAPON_INFO[hud.weapon].name}</span> — {WEAPON_INFO[hud.weapon].desc}
            </div>
            <div className="flex gap-1">
              {WEAPON_INFO.map((w, i) => {
                const active = hud.weapon === i;
                const ult = i === 10;
                const ready = ult && hud.ult >= 100;
                return (
                  <div
                    key={w.key}
                    className={`relative min-w-0 flex-1 border-2 px-1 py-1.5 skew-x-[-8deg] transition ${
                      active
                        ? "border-amber-300 bg-red-700/60 scale-110 z-10 shadow-[0_0_20px_rgba(251,191,36,0.6)]"
                        : ready
                          ? "border-amber-300/80 bg-amber-500/20 ult-ready"
                          : "border-white/20 bg-black/55 opacity-75"
                    }`}
                  >
                    <div className="skew-x-[8deg] text-center">
                      <div className="text-[10px] text-amber-200 font-black">[{w.key}]</div>
                      <div className="truncate text-[10px] sm:text-[11px] font-black leading-tight">{w.short}</div>
                      {active && (i === 3 || i === 10) && hud.charge > 0 && (
                        <div className="mt-1">
                          <Bar value={hud.charge} max={1} color="linear-gradient(90deg,#f97316,#fde047)" h="h-1.5" />
                        </div>
                      )}
                      {ult && !active && (
                        <div className="mt-1">
                          <Bar value={hud.ult} max={100} color="linear-gradient(90deg,#f59e0b,#fde047)" h="h-1" />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          {hud.morphing && (
            <div className="absolute bottom-[120px] left-1/2 -translate-x-1/2 text-cyan-200 text-xs font-black tracking-[0.3em] animate-pulse">
              NANOBOTS REFORMING…
            </div>
          )}

          {/* top right */}
          <div className="absolute top-4 right-4 flex flex-col items-end gap-2">
            <div className="text-sm font-bold text-white/80 bg-black/40 px-3 py-1 border border-white/10">⏱ {fmt(hud.time)}</div>
            <DownloadButtons compact />
          </div>

          {hud.status === "playing" && !hud.locked && (
            <div className="absolute top-24 right-4 text-[11px] text-white/60 text-right max-w-[230px]">
              คลิกบนเกมเพื่อล็อกเมาส์ — หรือกดลากเมาส์ขวาเพื่อหมุนกล้อง
            </div>
          )}
        </div>
      )}


      {showHud && deviceMode === "mobile" && hud.status === "playing" && (
        <div className="pointer-events-none absolute inset-0 z-20 touch-none">
          <div className="pointer-events-auto hidden">
            <span />
            {holdKey("KeyW", "▲", "col-start-2")}
            <span />
            {holdKey("KeyA", "◀", "")}
            {holdKey("KeyS", "▼", "")}
            {holdKey("KeyD", "▶", "")}
          </div>
          <div className="pointer-events-auto hidden">
            {holdKey("Space", "กระโดด / บิน", "w-28 h-14 text-xs")}
            {holdKey("ShiftLeft", "พุ่งหลบ", "w-28 h-11 text-xs")}
            <div className="hidden">
              <span />
              {holdKey("ArrowUp", "กล้อง ▲", "w-12 h-10 text-[10px]")}
              <span />
              {holdKey("ArrowLeft", "◀", "w-12 h-10")}
              {holdKey("ArrowDown", "▼", "w-12 h-10")}
              {holdKey("ArrowRight", "▶", "w-12 h-10")}
            </div>
          </div>
        </div>
      )}


      {showHud && deviceMode === "mobile" && hud.status === "playing" && (
        <>
          <div data-stick-area className="pointer-events-auto absolute bottom-7 left-5 z-30 flex h-36 w-36 touch-none items-center justify-center rounded-full border-2 border-white/50 bg-black/45 shadow-xl"
            onPointerDown={(e) => { e.preventDefault(); stickPointerRef.current = e.pointerId; e.currentTarget.setPointerCapture(e.pointerId); moveStick(e); }}
            onPointerMove={(e) => { if (stickPointerRef.current === e.pointerId) moveStick(e); }}
            onPointerUp={() => { stickPointerRef.current = null; releaseStick(); }} onPointerCancel={() => { stickPointerRef.current = null; releaseStick(); }} onLostPointerCapture={() => { stickPointerRef.current = null; releaseStick(); }}>
            <div className="pointer-events-none absolute h-24 w-24 rounded-full border border-white/25" />
            <div data-stick-knob className="pointer-events-none absolute h-14 w-14 rounded-full border-2 border-cyan-200 bg-cyan-400/50 shadow-lg" />
          </div>
          <div className="pointer-events-auto absolute inset-0 z-10 touch-none"
            onPointerDown={(e) => {
              if ((e.target as HTMLElement).closest("button, [data-stick-area]")) return;
              e.preventDefault();
              cameraTouchRef.current = { x: e.clientX, y: e.clientY };
              e.currentTarget.setPointerCapture(e.pointerId);
            }}
            onPointerMove={(e) => {
              const prev = cameraTouchRef.current;
              if (!prev) return;
              e.preventDefault();
              const dx = e.clientX - prev.x, dy = e.clientY - prev.y;
              cameraTouchRef.current = { x: e.clientX, y: e.clientY };
              gameRef.current?.touchLook(dx, dy);
            }}
            onPointerUp={() => { cameraTouchRef.current = null; }}
            onPointerCancel={() => { cameraTouchRef.current = null; }}
            onLostPointerCapture={() => { cameraTouchRef.current = null; }}
          />
          <div className="pointer-events-none absolute bottom-3 right-4 z-30 text-[10px] font-bold text-white/60">แตะพื้นที่ว่างแล้วลากเพื่อหมุนกล้อง</div>
        </>
      )}


      {showHud && deviceMode === "mobile" && hud.status === "playing" && (
        <div className="pointer-events-none absolute inset-0 z-40">
          <div className="pointer-events-auto absolute bottom-3 right-3 flex max-w-[56vw] flex-col items-end gap-1.5 touch-none">
            <div className="rounded-md border border-amber-300/40 bg-slate-950/85 px-2 py-1 text-[10px] font-bold leading-tight text-amber-200">
              {WEAPON_INFO[hud.weapon].name}
              <div className="font-normal text-white/70">{WEAPON_INFO[hud.weapon].desc}</div>
            </div>
            <div className="grid grid-cols-4 gap-1">
              {WEAPON_INFO.map((w, index) => (
                <button key={w.key} type="button"
                  onPointerUp={(e) => { e.preventDefault(); gameRef.current?.selectSkill(index); }}
                  className={`rounded-md border px-1 py-1.5 text-[9px] font-black leading-tight active:bg-cyan-500/60 ${hud.weapon === index ? "border-amber-300 bg-red-700/80 text-white" : index === 10 && hud.ult >= 100 ? "border-amber-300 bg-amber-500/30 text-amber-100 ult-ready" : "border-cyan-200/50 bg-slate-950/85 text-cyan-100"}`}>
                  <div className="text-amber-200">{w.key}</div>
                  {w.short}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <button type="button"
                onPointerDown={(e) => { e.preventDefault(); gameRef.current?.setAttackHeld(true); }}
                onPointerUp={() => gameRef.current?.setAttackHeld(false)}
                onPointerCancel={() => gameRef.current?.setAttackHeld(false)}
                onLostPointerCapture={() => gameRef.current?.setAttackHeld(false)}
                className="rounded-xl border border-amber-300/70 bg-red-700/85 px-4 py-2.5 text-sm font-black text-white active:scale-95">โจมตี</button>
              <button type="button" onClick={() => document.dispatchEvent(new KeyboardEvent("keydown", { code: "KeyT", key: "t", bubbles: true }))}
                className="rounded-xl border border-emerald-300/60 bg-emerald-900/80 px-3 py-2.5 text-xs font-black text-white active:scale-95">ซ่อมเกราะ [T]</button>
              {holdKey("ShiftLeft", "พุ่ง", "w-full h-11 text-xs")}
              {holdKey("Space", "บิน", "w-full h-11 text-xs")}
            </div>
            <button type="button"
              onPointerUp={(e) => { e.preventDefault(); const active = gameRef.current?.toggleSuit() ?? false; setTonyMode(active); }}
              className={tonyMode ? "w-full rounded-xl border border-amber-300 bg-amber-500/25 px-3 py-3 text-xs font-black text-amber-100" : "w-full rounded-xl border border-white/40 bg-black/80 px-3 py-3 text-xs font-black text-white"}>
              {tonyMode ? "ใส่ชุด MK-85" : "ถอดชุด · โทนี่กะต๊าก"}
            </button>
          </div>
        </div>
      )}
      {showHud && deviceMode === "desktop" && hud.status === "playing" && (
        <button type="button"
          onClick={() => { const active = gameRef.current?.toggleSuit() ?? false; setTonyMode(active); }}
          className={tonyMode ? "absolute right-6 top-24 z-40 rounded-xl border border-amber-300 bg-amber-500/25 px-4 py-3 text-sm font-black text-amber-100 shadow-xl" : "absolute right-6 top-24 z-40 rounded-xl border border-white/40 bg-black/80 px-4 py-3 text-sm font-black text-white shadow-xl"}>
          {tonyMode ? "ใส่ชุด MK-85" : "ถอดชุด · โทนี่กะต๊าก"}
        </button>
      )}

      {/* ---------------- MENU ---------------- */}
      {hud.status === "menu" && (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-black/70 via-black/40 to-black/80 overflow-y-auto">
          <div className="max-w-3xl w-full px-5 py-8 text-center">
            <div className="text-amber-300 tracking-[0.5em] text-xs font-bold mb-2">NANO TECH BOSS FIGHT</div>
            <h1 className="text-4xl sm:text-6xl font-black leading-none">
              <span className="text-red-500 drop-shadow-[0_0_5px_rgba(239,68,68,0.2)]">IRON MAN</span>
              <span className="text-amber-300"> MK-85</span>
              <div className="text-2xl sm:text-3xl text-white/80 my-2 tracking-widest">VS</div>
              <span className="text-purple-400 drop-shadow-[0_0_6px_rgba(168,85,247,0.22)]">THANOS</span>
            </h1>
            <p className="mt-5 text-white/80 text-sm sm:text-base leading-relaxed">
              สนามรบบนไททัน — ธานอสถือเกาน์ทเล็ตอินฟินิตี้อยู่ตรงหน้า สวมเกราะนาโนเทคโนโลยี Iron Man Mark 85 (LXXXV) จาก Avengers: Endgame ที่แปลงอนุภาคนาโนเป็นอาวุธและอุปกรณ์ได้ทุกแบบ
              <br />
              โจมตีเปลี่ยนอาวุธได้ทันที แล้วโค่นเขาให้ได้!
            </p>

            <div className="mt-5 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 text-left">
              {WEAPON_INFO.map((w) => (
                <div key={w.key} className="border border-amber-300/30 bg-black/50 p-2">
                  <div className="text-[10px] text-amber-300 font-black">
                    [{w.key}] {w.name}
                  </div>
                  <div className="text-sm font-bold">{w.th}</div>
                  <div className="text-[11px] text-white/60">{w.desc}</div>
                </div>
              ))}
            </div>

            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 text-left text-xs bg-black/50 border border-white/10 p-3">
              {KEYS.map(([k, d]) => (
                <div key={k} className="flex gap-2">
                  <span className="shrink-0 min-w-[96px] font-bold text-cyan-200">{k}</span>
                  <span className="text-white/75">{d}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => setChooseMode(true)}
              className="mt-6 cursor-pointer px-12 py-4 text-xl font-black tracking-widest bg-gradient-to-b from-red-500 to-red-700 border-2 border-amber-300 hover:scale-105 active:scale-95 transition shadow-[0_0_30px_rgba(239,68,68,0.6)]"
            >
              ▶ เริ่มเกม
            </button>
            <div className="mt-5">
    
            </div>
          </div>
        </div>
      )}


      {chooseMode && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/95 p-5">
          <div className="w-full max-w-xl border border-amber-300/50 bg-slate-950/95 p-6 text-center shadow-2xl">
            <div className="text-amber-300 text-xs font-black tracking-[0.35em]">SELECT CONTROL MODE</div>
            <h2 className="mt-3 text-2xl sm:text-3xl font-black">เล่นบนอุปกรณ์ไหน?</h2>
            <p className="mt-2 text-sm text-white/60">เลือกวิธีควบคุมก่อนเข้าสู่สนาม</p>
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button onClick={() => { setDeviceMode("desktop"); setChooseMode(false); gameRef.current?.start(); }}
                className="border border-cyan-300/60 bg-cyan-500/10 p-5 text-left hover:bg-cyan-500/20 active:scale-95">
                <div className="text-4xl">🖥️</div><div className="mt-2 text-lg font-black">คอมพิวเตอร์</div>
                <div className="text-xs text-white/60">คีย์บอร์ด + เมาส์</div>
              </button>
              <button onClick={() => { setDeviceMode("mobile"); setChooseMode(false); gameRef.current?.start(); }}
                className="border border-amber-300/60 bg-amber-500/10 p-5 text-left hover:bg-amber-500/20 active:scale-95">
                <div className="text-4xl">📱</div><div className="mt-2 text-lg font-black">โทรศัพท์</div>
                <div className="text-xs text-white/60">ปุ่มสัมผัสบนหน้าจอ</div>
              </button>
            </div>
            <button onClick={() => setChooseMode(false)} className="mt-5 px-5 py-2 text-sm text-white/60 hover:text-white">← กลับ</button>
          </div>
        </div>
      )}

      {/* ---------------- PAUSE ---------------- */}
      {hud.status === "paused" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 bg-black/65 pointer-events-auto">
          <div className="text-4xl font-black tracking-[0.3em]">PAUSED</div>
          <button
            onClick={() => gameRef.current?.resume()}
            className="cursor-pointer px-10 py-3 text-lg font-black tracking-widest bg-gradient-to-b from-red-500 to-red-700 border-2 border-amber-300 hover:scale-105 transition"
          >
            ▶ เล่นต่อ
          </button>

        </div>
      )}

      {/* ---------------- WIN / LOSE ---------------- */}
      {(hud.status === "won" || hud.status === "lost") && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-black/70 text-center px-4 pointer-events-auto">
          {hud.status === "won" ? (
            <>
              <div className="text-amber-300 tracking-[0.4em] text-xs font-bold">THANOS DEFEATED</div>
              <div className="text-5xl sm:text-6xl font-black text-amber-300 drop-shadow-[0_0_30px_rgba(251,191,36,0.7)]">ชัยชนะ!</div>
              <p className="text-white/80 max-w-md">
                “ฉันคือ Iron Man…” — คุณโค่นธานอสได้ภายในเวลา <b className="text-cyan-200">{fmt(hud.time)}</b>
              </p>
            </>
          ) : (
            <>
              <div className="text-red-400 tracking-[0.4em] text-xs font-bold">ARMOR OFFLINE</div>
              <div className="text-5xl sm:text-6xl font-black text-red-500 drop-shadow-[0_0_30px_rgba(239,68,68,0.7)]">พ่ายแพ้</div>
              <p className="text-white/80 max-w-md">
                ธานอสยังเหลือพลังชีวิต {Math.round(bossPct * 100)}% — ลองใช้ PARRY ด้วยโล่ และปัดลูกพลังงานกลับด้วยดาบ
              </p>
            </>
          )}
          <button
            onClick={() => gameRef.current?.start()}
            className="cursor-pointer mt-2 px-10 py-3 text-lg font-black tracking-widest bg-gradient-to-b from-red-500 to-red-700 border-2 border-amber-300 hover:scale-105 transition"
          >
            ↻ เล่นอีกครั้ง
          </button>

        </div>
      )}
    </div>
  );
}
